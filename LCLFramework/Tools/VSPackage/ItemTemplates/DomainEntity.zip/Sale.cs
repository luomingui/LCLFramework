﻿using UIShell.RbacPermissionService;

namespace UIShell.OneCardService
{
    /// <summary>
    /// 销售表
    /// </summary>
    public partial class $safeitemname$ : BaseModel
    {
        public $safeitemname$()
        {
           // Price = AppConstant.Price;
        }
        /// <summary>
        /// 数量
        /// </summary>
        public int Quantity { get; set; }
        /// <summary>
        /// 价格
        /// </summary>
        public int Price { get; set; }
        /// <summary>
        /// 折扣
        /// </summary>
        public int Discount { get; set; }
        /// <summary>
        /// 销售员
        /// </summary>
        public User User { get; set; }
    }
}
