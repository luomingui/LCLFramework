﻿using UIShell.RbacPermissionService;

namespace UIShell.OneCardService
{
    /// <summary>
    /// 销售表
    /// </summary>
    public partial class $safeitemname$ : BaseModel
    {
        public $safeitemname$()
        {
          
        }
       
    }
}
