﻿using LCL;
using LCL.ComponentModel;
using System.Diagnostics;
using LCL.MvcExtensions;

namespace $safeprojectname$
{
    public class BundleActivator : LCLPlugin
    {
        public override void Initialize(IApp app)
        {
            Debug.WriteLine("BootstrapAppCenterPlugin Initialize....");
            Bundle = this;
            
            PageFlowService.PageNodes.AddPageNode(new PageNode
            {
                Name = "LayoutPage",
                Bundle = this,
                Value = @"~\Plugins\$safeprojectname$\Views\Shared\_Layout.cshtml",
                Priority = 0
            });
        }
    }
}
