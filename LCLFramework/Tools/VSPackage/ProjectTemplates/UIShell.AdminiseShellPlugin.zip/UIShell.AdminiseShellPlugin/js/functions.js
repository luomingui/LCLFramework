$(window).scroll(function () {
    var scroll = $(window).scrollTop();

    if (scroll >= 145) {
        $(".effect").addClass("affix");
    } else {
        $(".effect").removeClass("affix");
    }
});

// Close and toggle buttons
$(document).ready(function () {
	$("div a.closethis").click(function(){
	  $(this).parent().hide();
	});
	$("a.togglethis").click(function(){
		$( this ).toggleClass( "clicked" );
	    $(this).parent().toggleClass("hidden-sec");
	});
});
// add scroll to div
$(document).ready(function() {
  $(".scroller").customScrollbar();
});
// Tabs
$(function () {
	$('#myTab a:first').tab('show')
	$('#myTabdark a:first').tab('show')
})

$(document).ready(function(){
    // tooltip demo
    $('.tooltip-demo').tooltip({
      selector: "[data-toggle=tooltip]",
      container: "body"
    })
	
	// popover demo
    $("[data-toggle=popover]")
      .popover()
	
	$(".alert").alert()
});
$(document).ready(function(){
	selectnav('nav1', {
	  label: 'Menu',
	  nested: true,
	  indent: '-'
	});
});
$(document).ready(function(){
	selectnav('nav2', {
	  label: 'Menu',
	  nested: true,
	  indent: '-'
	});
});
$(document).ready(function(){
	selectnav('nav3', {
	  label: 'Menu',
	  nested: true,
	  indent: '-'
	});
});
$(document).ready(function(){
	selectnav('nav4', {
	  label: 'Inbox Menu',
	  nested: true,
	  indent: '-'
	});
});

$(document).ready(function () {
	$('#myModal').modal('hide')

});

$(document).ready(function () {
	$('ul.navi-acc').accordion();
});
$(document).ready(function () {
	$( ".collapsed" ).addClass( "sidebarhidden" );
});
// Vin 
//2014/04/23 ����ԭ��������JS����
$(document).ready(function () {
    var $datepicker = $(".date-picker");
    if ($datepicker.length > 0) {
        $datepicker.each(function () {
            if (typeof ($(this).attr("data-date-format")) == "undefined") {
                $(this).attr("data-date-format", "YYYY-MM-DD");
            }
            $(this).datetimepicker({
                language: "zh-cn",
                showToday: true,
                pickTime: false
            });
        });
    }
    var $timepicker = $(".time-picker");
    if ($timepicker.length > 0) {
        $timepicker.each(function () {
            if (typeof ($(this).attr("data-date-format")) == "undefined") {
                $(this).attr("data-date-format", "HH:mm");
            }
            $(this).datetimepicker({
                language: "zh-cn",
                showToday: true,
                pickDate: false
            });
        });
    }
    var $timehourpicker = $(".timehour-picker");
    if ($timehourpicker.length > 0) {
        $timehourpicker.each(function () {
            if (typeof ($(this).attr("data-date-format")) == "undefined") {
                $(this).attr("data-date-format", "HH");
            }
            $(this).datetimepicker({
                language: "zh-cn",
                showToday: true,
                pickDate: false,
                useMinutes:false
            });
        });
    }
    var $datetimepicker = $(".datetime-picker");
    if ($datetimepicker.length > 0) {
        $datetimepicker.each(function () {
            if (typeof ($(this).attr("data-date-format")) == "undefined") {
                $(this).attr("data-date-format", "YYYY-MM-DD HH:mm");
            }
            $(this).datetimepicker({
                language: "zh-cn",
                showToday: true
            });
        });
    }
    var $datehourpicker = $(".datehour-picker");
    if ($datehourpicker.length > 0) {
        $datehourpicker.each(function () {
            if (typeof ($(this).attr("data-date-format")) == "undefined") {
                $(this).attr("data-date-format", "YYYY-MM-DD HH");
            }
            $(this).datetimepicker({
                language: "zh-cn",
                showToday: true,
                useMinutes: false
            });
        });
    }
    var $tableAutoWidth = $("div[data-autotable]");
    if ($tableAutoWidth.length > 0) {
        $tableAutoWidth.each(function () {
            var attrArr = new Array('', '', ''),
                attrStr = $(this).attr("data-autotable");
            var tempArr = attrStr.split('|');
            for (var i = 0; i < tempArr.length; i++) {
                attrArr[i] = parseInt(tempArr[i]);
            }
            if (attrArr[1] == '') attrArr[1] = 55;
            if (attrArr[2] == '') attrArr[2] = 100;
            var width = $(this).parent().width(),
                $tb = $(this).find("table:eq(0)"),
                tbWidth = $tb.width(),
                tbHeight = $tb.height(),
                trNumHeight = $tb.find("tbody>tr:visible").length * attrArr[1] + attrArr[2];

            //alert(tempArr.length + "---" + attrStr +"---"+ attrArr[0] + "---" + attrArr[1] + "---" + attrArr[2]);
            $(this).find("table:eq(0)").width(attrArr[0]);
            //alert($(window).width() - 270 + "--" + $(this).find(".sidebar").width() + "---" + width + "---" + $(this).find("table:eq(0)").width() + "----" + $(this).find(".sidebar-in").width());
            //width = $(window).width() * 0.78;
            //alert($(".sec-box").width() + "---" + $(this).parents(".sec-box:eq(0)").width());
            $(this).css({
                width: (width - 30) + "px",
                //width: $(window).width() - 360 + "px",
                //minheight:(height - 40)+"px",
                height: trNumHeight + "px",//height + 
                position: "relative",
                overflow: "auto"
            });
        });
    }
});