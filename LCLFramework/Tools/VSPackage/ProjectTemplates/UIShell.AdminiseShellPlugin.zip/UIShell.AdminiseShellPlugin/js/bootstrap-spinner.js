﻿/*================================
*开发:Vin
*日期:2014/05/29
*版本:0.1 
*功能:
1. 可定义步长
2. 可设置限制范围
==================================*/
$(function () {
    (function ($) {
        $(".spinner").each(function (index) {
            var __self = $(".spinner:eq(" + index + ")"),
                __step = parseFloat($(this).attr("data-spinner-step")),
                //设置是否启用按钮
                __isBtn = true,
                __range = $(this).attr("data-spinner-range"),
                __isRange = false,
                __minNum = 0,
                __maxNum = 0,
                __digit = parseInt($(this).attr("data-spinner-digit")),
                __$upBtn = __self.find('.btn:first-of-type'),
                __$downBtn = __self.find('.btn:last-of-type'),
                __$input = __self.find('input'),
                __defValIpt = __$input.val();
            //设置默认步长1
            __step = isNaN(__step) ? 1 : __step;
            //设置默认小数位 0
            __digit = isNaN(__digit) ? 0 : __digit;
            //设置数值范围，起始、结束值
            if (typeof (__range) != "undefined") {
                var rangeArr = __range.split(',');
                __isRange = true;
                __minNum = parseFloat(rangeArr[0]);
                __maxNum = parseFloat(rangeArr[1]);
            }
            __$upBtn.on('click', function () {
                var increaseNum = parseFloat(parseFloat(__$input.val()) + __step);
                if (__isRange) {
                    increaseNum = getCheckRange(increaseNum, __minNum, __maxNum, __$upBtn, __$downBtn);
                }
                __$input.val(increaseNum.toFixed(__digit));
            });
            __$downBtn.on('click', function () {
                var decreaseNum = parseFloat(parseFloat(__$input.val()) - __step);
                if (__isRange) {
                    decreaseNum = getCheckRange(decreaseNum, __minNum, __maxNum, __$upBtn, __$downBtn);
                }
                __$input.val(decreaseNum.toFixed(__digit));
            });
            __$input.on("blur", function () {
                var inputVal = __$input.val();
                if (isNaN(parseFloat(inputVal))) {
                    inputVal = __defValIpt;
                } else {
                    inputVal = inputVal;
                }
                if (__isRange) {
                    inputVal = getCheckRange(inputVal, __minNum, __maxNum, __$upBtn, __$downBtn);
                }
                __$input.val(inputVal);
            });
        });
        //判断数值范围,并返回处理值
        function getCheckRange(_curNum, _minNum, _maxNum, _$upBtn, _$downBtn) {
            var rNum = _curNum;
            if (_curNum >= _maxNum) {
                rNum = _maxNum;
                switchBtn(_$upBtn, _$downBtn, new Array(true, false));
            } else if (_curNum <= _minNum) {
                rNum = _minNum;
                switchBtn(_$upBtn, _$downBtn, new Array(false, true));
            } else {
                switchBtn(_$upBtn, _$downBtn, new Array(false, false));
            }
            return rNum;
        }
        //切换上、下按钮状态
        function switchBtn(_$upBtn, _$downBtn, _statusArr) {
            _$upBtn.prop('disabled', _statusArr[0]);
            _$downBtn.prop('disabled', _statusArr[1]);
        }
    })(jQuery);
});
