﻿using LCL.DomainEntitys;
using System;

namespace $safeprojectname$
{
    /// <summary>
    /// 模型基类
    /// </summary>
    [Serializable]
    public class MyEntity : DomainEntity
    {
       
    }
}
