﻿using LCL;
using LCL.Repositories.EntityFramework;
using System;
using System.Data.Entity;

namespace $safeprojectname$
{
    public class EFContext : BaseDbContext
    {
        public EFContext(): base("RBAC")
        {

        }
        //RBAC
        public DbSet<User> Org { get; set; }
    }

    /// <summary>
    /// 数据库初始化操作类
    /// </summary>
    internal static class DatabaseInitializer
    {
        /// <summary>
        /// 数据库初始化
        /// </summary>
        public static void Initialize()
        {
            try
            {
                Database.SetInitializer<EFContext>(new DropCreateDatabaseIfModelChanges<EFContext>());
                Database.SetInitializer(new SampleData());
                using (var db = new EFContext())
                {
                    db.Database.Initialize(false);
                }
            }
            catch (Exception ex)
            {
                Logger.LogError("DatabaseInitializer ", ex);
            }
        }
    }

    /// <summary>
    /// 数据库初始化策略
    /// </summary>
    internal class SampleData : CreateDatabaseIfNotExists<EFContext>
    {
        protected override void Seed(EFContext context)
        {
            //RBAC
            //var org = context.Set<Org>().Add(new Org { ID = Guid.NewGuid(), Name = "研发部" });
            //context.SaveChanges();
        }
    }
}
