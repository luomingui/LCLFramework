using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;

namespace $safeprojectname$
{
    [MetadataType(typeof(VillageMD))]
    public partial class Village
    {
        //http://www.cnblogs.com/yeagen/archive/2012/09/24/2700836.html
        public class VillageMD
        {
            [Required(ErrorMessage = "请输入{0}")]//必填字段
            [StringLength(20, ErrorMessage = "{0}在{2}位至{1}位之间", MinimumLength = 2)]//字段长度
            [Display(Name = "小区名称")]
            public String Name { get; set; }

        }
    } 
}
