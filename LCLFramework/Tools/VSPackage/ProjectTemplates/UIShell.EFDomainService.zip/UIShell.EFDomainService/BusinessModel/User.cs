﻿using System;
using System.Diagnostics;

namespace $safeprojectname$
{
    /// <summary>
    /// 用户
    /// </summary>
    [Serializable]
    public partial class User : MyEntity
    {
        public string Name { set; get; }
    }
}
