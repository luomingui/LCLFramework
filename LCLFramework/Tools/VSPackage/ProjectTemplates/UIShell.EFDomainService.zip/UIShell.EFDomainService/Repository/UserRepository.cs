﻿using LCL;
using LCL.Repositories;
using LCL.Repositories.EntityFramework;
using System;
using System.Linq;

namespace $safeprojectname$
{
    public interface IUserRepository : IRepository<User>
    {

    }
    [Serializable]
    [RepositoryFor(typeof(User))]
    public class UserRepository : EntityFrameworkRepository<User>, IUserRepository
    {
        public UserRepository(IRepositoryContext context)
            : base(context)
        {

        }
      
    }
}
