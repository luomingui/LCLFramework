﻿
using LCL;
using LCL.ComponentModel;
using LCL.MetaModel;
using LCL.MvcExtensions;
using System.Diagnostics;

namespace $safeprojectname$
{
    public class BundleActivator : LCLPlugin
    {
        public override void Initialize(IApp app)
        {
            Debug.WriteLine("$safeprojectname$ Initialize....");
            app.ModuleOperations += app_ModuleOperations;
        }
        void app_ModuleOperations(object sender, System.EventArgs e)
        {
            Debug.WriteLine("$safeprojectname$ app_ModuleOperations Meuns....");
            CommonModel.Modules.AddRoot(new MvcModuleMeta
            {
                Label = "界面元素",
                Image = "icon-home",
                Children =
                {
                    new MvcModuleMeta{ Label = "元素", CustomUI="/$safeprojectname$/Home/UserInterface"},
                    new MvcModuleMeta{ Label = "表格", CustomUI="/$safeprojectname$/Home/Tables"},
                    new MvcModuleMeta{ Label = "窗体", CustomUI="/$safeprojectname$/Home/Form"},
                    new MvcModuleMeta{ Label = "小窗口", CustomUI="/$safeprojectname$/Home/Widgets"},
                }
            });
            CommonModel.Modules.AddRoot(new MvcModuleMeta
            {
                Label = "统计图表",
                Image = "icon-bar-chart",
                Children =
                {
                    new MvcModuleMeta{ Label = "图表", CustomUI="/$safeprojectname$/Home/Charts"},
                }
            });
            CommonModel.Modules.AddRoot(new MvcModuleMeta
            {
                Label = "页面",
                Image = "icon-comment",
                Children =
                {
                    new MvcModuleMeta{ Label = "Error Log", CustomUI="/$safeprojectname$/Home/ErrorLog"},
                    new MvcModuleMeta{ Label = "Invoice", CustomUI="/$safeprojectname$/Home/Invoice"},
                    new MvcModuleMeta{ Label = "Make Post", CustomUI="/$safeprojectname$/Home/MakePost"},
                    new MvcModuleMeta{ Label = "Profile", CustomUI="/$safeprojectname$/Home/Profile"},
                    new MvcModuleMeta{ Label = "Media", CustomUI="/$safeprojectname$/Home/Media"},
                }
            });
        }
    }
}
