﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace $safeprojectname$.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }
        public ActionResult Tiles()
        {
            return View();
        }

        public ActionResult Buttons()
        {
            return View();
        }

        public ActionResult Tabs()
        {
            return View();
        }

        public ActionResult Paragraph()
        {
            return View();
        }

        public ActionResult Tooltips()
        {
            return View();
        }

        public ActionResult Navbars()
        {
            return View();
        }

        public ActionResult Breadcrumbs()
        {
            return View();
        }

        public ActionResult Pagination()
        {
            return View();
        }
        public ActionResult ProgressBars()
        {
            return View();
        }
        public ActionResult Blockquotes()
        {
            return View();
        }
        public ActionResult Modal()
        {
            return View();
        }
        public ActionResult Alerts()
        {
            return View();
        }
        public ActionResult Labels()
        {
            return View();
        }
        public ActionResult Comments()
        {
            return View();
        }
        public ActionResult Charts()
        {
            return View();
        }
        public ActionResult DataTables()
        {
            return View();
        }

        public ActionResult BasicTables()
        {
            return View();
        }
        public ActionResult BasicForms()
        {
            return View();
        }

        public ActionResult InputGroups()
        {
            return View();
        }
        public ActionResult CheckBoxes()
        {
            return View();
        }
        public ActionResult Switches()
        {
            return View();
        }
        public ActionResult WYSIWYG()
        {
            return View();
        }
        public ActionResult Sliders()
        {
            return View();
        }
    }
}