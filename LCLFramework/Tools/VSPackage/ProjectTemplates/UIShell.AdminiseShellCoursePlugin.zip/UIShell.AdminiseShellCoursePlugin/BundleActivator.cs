﻿
using LCL;
using LCL.ComponentModel;
using LCL.MetaModel;
using LCL.MvcExtensions;
using System.Diagnostics;

namespace $safeprojectname$
{
    public class BundleActivator : LCLPlugin
    {
        public override void Initialize(IApp app)
        {
            Debug.WriteLine("$safeprojectname$ Initialize....");
            app.ModuleOperations += app_ModuleOperations;
        }
        void app_ModuleOperations(object sender, System.EventArgs e)
        {
            Debug.WriteLine("$safeprojectname$ app_ModuleOperations Meuns....");
            CommonModel.Modules.AddRoot(new MvcModuleMeta
            {
                Label = "界面元素",
                Image = "glyphicon glyphicon-bell",
                Children =
                {
                    new MvcModuleMeta{ Label = "磁贴", CustomUI="/$safeprojectname$/Home/Tiles"},
                    new MvcModuleMeta{ Label = "按钮", CustomUI="/$safeprojectname$/Home/Buttons"},
                    new MvcModuleMeta{ Label = "标签页", CustomUI="/$safeprojectname$/Home/Tabs"},
                    new MvcModuleMeta{ Label = "排版", CustomUI="/$safeprojectname$/Home/Paragraph"},
                    new MvcModuleMeta{ Label = "提示", CustomUI="/$safeprojectname$/Home/Tooltips"},
                    new MvcModuleMeta{ Label = "导航条", CustomUI="/$safeprojectname$/Home/Navbars"},
                    new MvcModuleMeta{ Label = "面包屑导航", CustomUI="/$safeprojectname$/Home/Breadcrumbs"},
                    new MvcModuleMeta{ Label = "分页", CustomUI="/$safeprojectname$/Home/Pagination"},
                    new MvcModuleMeta{ Label = "进度条", CustomUI="/$safeprojectname$/Home/ProgressBars"},
                    new MvcModuleMeta{ Label = "引用", CustomUI="/$safeprojectname$/Home/Blockquotes"},
                    new MvcModuleMeta{ Label = "模式窗口", CustomUI="/$safeprojectname$/Home/Modal"},
                    new MvcModuleMeta{ Label = "警告框", CustomUI="/$safeprojectname$/Home/Alerts"},
                    new MvcModuleMeta{ Label = "标签", CustomUI="/$safeprojectname$/Home/Labels"},
                    new MvcModuleMeta{ Label = "备注", CustomUI="/$safeprojectname$/Home/Comments"},
                }
            });
            CommonModel.Modules.AddRoot(new MvcModuleMeta
            {
                Label = "图表",
                Image = "charts",
                Children =
                {
                    new MvcModuleMeta{ Label = "图表", CustomUI="/$safeprojectname$/Home/Charts"},
                }
            });
            CommonModel.Modules.AddRoot(new MvcModuleMeta
            {
                Label = "表格",
                Image = "pages",
                Children =
                {
                    new MvcModuleMeta{ Label = "数据表格", CustomUI="/$safeprojectname$/Home/DataTables"},
                    new MvcModuleMeta{ Label = "基本表格", CustomUI="/$safeprojectname$/Home/BasicTables"},
                }
            });
            CommonModel.Modules.AddRoot(new MvcModuleMeta
            {
                Label = "页面",
                Image = "forms",
                Children =
                {
                    new MvcModuleMeta{ Label = "基本窗体", CustomUI="/$safeprojectname$/Home/BasicForms"},
                    new MvcModuleMeta{ Label = "输入组", CustomUI="/$safeprojectname$/Home/InputGroups"},
                    new MvcModuleMeta{ Label = "复选框", CustomUI="/$safeprojectname$/Home/CheckBoxes"},
                    new MvcModuleMeta{ Label = "开关", CustomUI="/$safeprojectname$/Home/Switches"},
                    new MvcModuleMeta{ Label = "编辑器", CustomUI="/$safeprojectname$/Home/WYSIWYG"},
                    new MvcModuleMeta{ Label = "滑动条", CustomUI="/$safeprojectname$/Home/Sliders"},
                }
            });
        }
    }
}
