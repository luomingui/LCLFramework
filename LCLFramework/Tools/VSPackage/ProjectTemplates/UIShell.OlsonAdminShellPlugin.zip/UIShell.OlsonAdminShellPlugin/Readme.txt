﻿------UIShell.OlsonAdminShellPlugin设计基调------
1:OlsonAdminShell是Bootstrap v3.0.0蓝白界面模板
2:其他插件使用在Views/_ViewStart.cshtml即合继承主界面框架
_ViewStart.cshtml内容如下
@{
    Layout = @Url.Content(LCL.MvcExtensions.PageFlowService.PageNodes.DefaultLayoutPageNode);
}
